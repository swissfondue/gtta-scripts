================================================================
Spy Lantern Keylogger Pro v5.4.1 for Windows XP/2000/2003 Server
================================================================

Overview
========

Spy Lantern Keylogger is a spy software intended for monitoring all aspects
of user activity. It allows you to see what exactly they are doing on your
PC. You can see every keystroke they've typed in every application. This
means that you can get every e-mail they've sent via e-mail client or
web based e-mail service. Spy Lantern Keylogger records both sides of chat
conversations of ICQ, Yahoo, ICQ, MSN and various other Chat/IM programs.
It records every online resource they've visited in the Internet or
Intranet. You can see every password they've entered, every application
they've used and duration of their work. Spy Lantern Keylogger records
every user's logon, every power on and power off on your PC.

Spy Lantern Keylogger is the first totally invisible keylogger. So no one
can determine that you are watching on him. Additionally Spy Lantern
Keylogger is password protected. This means that no one can configure,
view reports or even uninstall Spy Lantern Keylogger without supplying
valid password. 

Unlike other spy software, Spy Lantern Keylogger works excellent in both
Windows XP with Fast User Switch enabled and Windows Terminal Services.
It also has intuitive user interface and amazing easy-to-understand
Reports Viewer with eye catching reports. Using such a powerful tool like
Spy Lantern Keylogger you'll be enlightened of what they are doing while
you are away.

Spy Lantern Keylogger features:
===============================

Monitoring:
----------
- Keystrokes
- Web sites
- Passwords
- Both sides of chat conversations (ICQ, Yahoo, AIM, MSN)
- Applications
- Application total time and application using time
- Power on/off/interrupt events
- Hibernate and resume events
- User log on/off events

Reports delivery:
-----------------
- Email
- Local disk

Security:
---------
- Total invisibility
- Password protected configuration
- Password protected uninstall
- Encrypted report file
- Hotkey program access

Other:
------
- Windows XP with Fast User Switch enabled compatibility
- Windows Terminal Services compatibility
- User-friendly interface
- Easy-to-understand Reports Viewer with eye catching reports

System requirements:
====================

No special requirements for hardware or software. If your computer can
run Microsoft Windows 2000/XP/2000 Server/2003 Server operating systems,
the Spy Lantern Keylogger will run as well.


How to contact us:
==================

You can contact us at:
http://www.spy-lantern.com/contacts.html

In general we prefer email communication because to accordance with our
experience user describes his problem/request/suggestion in more
understandable form while he composes email text. Usually we answer to
all emails within 48 hours maximum.

Before you contact us, please do the following:

- Be sure that you're doing everything right. We all make mistakes
  sometimes... Be attentive.
- Look at the program Help file: it may already contain an answer to your
  question. A lot of people ask us something like "how do I..." though the
  complete information is there.
- Visit product home page in the Internet at:
  http://www.spy-lantern.com/download.html
  It's a good chance that you'll find the newer version of program there.
  If the serious bug has been found in the program, but the new version is
  not ready yet, we make the hot fix for it.

But if you still have a problem with program and noting else helps, please
contact our technical support team.

To get answer as soon as possible please inform us about the following:

- Program version (from "About" menu);
- Where did you get our program (http or ftp site);
- Windows version (including service packs and other fixes installed), US
  or international, OEM or not;
- Computer information: CPU type and speed, installed memory;
- Description of your problem (as much information as possible so
  developers could reconstruct your exact situation in the lab).
